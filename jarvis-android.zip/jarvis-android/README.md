# Jarvis for Android

A phone assistant in an Iron Man style HUD. The screen is a web page (`app/src/main/assets/index.html`) running inside a native Android shell that adds:

- Spoken replies through Android text-to-speech, with a voice picker.
- Voice input through Android speech recognition, including hands-free mode.
- Reminders as real system alarms. They fire even when the app is closed and are restored after a reboot.
- Chat powered by your own Anthropic API key, entered in the Setup tab. The key stays on the phone and requests go straight to Anthropic.

## Get the APK without a computer (GitHub cloud build)

1. Create a free GitHub account and a new empty repository named `jarvis-android`.
2. Upload this project's files to it, keeping the folder structure (including the hidden `.github` folder).
3. Open the repository's **Actions** tab, choose **Build APK**, and tap **Run workflow**. A push to `main` also starts it.
4. When the run finishes (about 5 minutes), open it and download the `jarvis-apk` artifact. Unzip it to get `app-debug.apk`.
5. Open the APK on your phone and allow "Install unknown apps" for your browser or file manager when asked.

## Build it yourself

Open the folder in Android Studio and run the `app` configuration, or from a terminal with JDK 17 and Gradle 8.9 run `gradle assembleDebug`. The APK is written to `app/build/outputs/apk/debug/`.

## First run

1. Open the **Setup** tab, paste your Anthropic API key, choose a model and tap **Save**.
2. Tap **Allow mic and notifications** and accept both prompts.
3. Pick a voice, speed and look. Try **Hands-free** if you want Jarvis to keep listening after each reply.

## Limits

- Jarvis opens apps by preparing links you tap. It cannot send messages, place calls or read your phone's content.
- This is a debug build for personal use, not a Play Store release.
- Keep your API key private and set a spending limit on it in the Anthropic Console.
