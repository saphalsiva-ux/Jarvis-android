package com.jarvis.assistant

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

/**
 * Schedules reminders as system alarms so they fire even when the app is closed.
 * Pending reminders are also kept in SharedPreferences so they survive a reboot.
 */
object Reminders {
    private const val PREFS = "jarvis_reminders"

    fun schedule(ctx: Context, id: String, text: String, whenMs: Long) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(id, "$whenMs|$text").apply()
        arm(ctx, id, text, whenMs)
    }

    fun cancel(ctx: Context, id: String) {
        forget(ctx, id)
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val existing = PendingIntent.getBroadcast(
            ctx,
            id.hashCode(),
            Intent(ctx, ReminderReceiver::class.java),
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (existing != null) {
            am.cancel(existing)
            existing.cancel()
        }
    }

    fun forget(ctx: Context, id: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(id).apply()
    }

    fun restore(ctx: Context) {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        for ((id, value) in prefs.all) {
            val raw = value as? String ?: continue
            val sep = raw.indexOf('|')
            if (sep < 0) continue
            val at = raw.substring(0, sep).toLongOrNull() ?: continue
            if (at > now) {
                arm(ctx, id, raw.substring(sep + 1), at)
            } else {
                prefs.edit().remove(id).apply()
            }
        }
    }

    private fun arm(ctx: Context, id: String, text: String, whenMs: Long) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val fire = PendingIntent.getBroadcast(
            ctx,
            id.hashCode(),
            Intent(ctx, ReminderReceiver::class.java)
                .putExtra("id", id)
                .putExtra("text", text),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val show = PendingIntent.getActivity(
            ctx,
            0,
            Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        am.setAlarmClock(AlarmManager.AlarmClockInfo(whenMs, show), fire)
    }
}
