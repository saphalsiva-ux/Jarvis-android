package com.jarvis.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingVoice: String? = null
    private var recognizer: SpeechRecognizer? = null
    private var pendingListenLang: String? = null

    private val speakEndJs = "window.__jv&&window.__jv.speakEnd&&window.__jv.speakEnd()"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bg = Color.parseColor("#050A10")
        window.statusBarColor = bg
        window.navigationBarColor = bg

        web = WebView(this)
        web.setBackgroundColor(bg)
        setContentView(web)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val uri = request?.url ?: return null
                return loader.shouldInterceptRequest(uri)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val uri = request?.url ?: return true
                if (uri.host == "appassets.androidplatform.net") return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                    // No app can open this link; ignore.
                }
                return true
            }
        }

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")

        initSpeech()

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
        }
        Reminders.restore(this)
    }

    private fun js(code: String) {
        runOnUiThread { web.evaluateJavascript(code, null) }
    }

    private fun granted(permission: String) =
        checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

    /* ---------- text to speech ---------- */

    private fun initSpeech() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.language = Locale.UK
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        js(speakEndJs)
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        js(speakEndJs)
                    }
                })
                pendingVoice?.let { applyVoice(it) }
            }
        }
    }

    private fun applyVoice(name: String) {
        if (name.isEmpty()) {
            tts?.language = Locale.UK
            return
        }
        tts?.voices?.firstOrNull { it.name == name }?.let { tts?.voice = it }
    }

    /* ---------- speech recognition ---------- */

    private fun beginListening(lang: String) {
        if (!granted(Manifest.permission.RECORD_AUDIO)) {
            pendingListenLang = lang
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("window.__jv&&window.__jv.listenEnd('unavailable')")
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {
                deliver(partialResults, false)
            }

            override fun onResults(results: Bundle?) {
                deliver(results, true)
            }

            override fun onError(error: Int) {
                val code = when (error) {
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "denied"
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "nomatch"
                    else -> "error"
                }
                js("window.__jv&&window.__jv.listenEnd('$code')")
            }
        })
        recognizer = r
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            }
        )
    }

    private fun deliver(bundle: Bundle?, isFinal: Boolean) {
        val text = bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        if (text == null) {
            if (isFinal) js("window.__jv&&window.__jv.listenEnd('nomatch')")
            return
        }
        js("window.__jv&&window.__jv.heard(" + JSONObject.quote(text) + "," + isFinal + ")")
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10) {
            val lang = pendingListenLang
            pendingListenLang = null
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED && lang != null) {
                beginListening(lang)
            } else {
                js("window.__jv&&window.__jv.listenEnd('denied')")
            }
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        recognizer?.destroy()
        web.destroy()
        super.onDestroy()
    }

    /* ---------- bridge exposed to the page as window.Android ---------- */

    inner class Bridge {
        @JavascriptInterface
        fun speak(text: String, rate: Double, pitch: Double) {
            runOnUiThread {
                if (!ttsReady) {
                    js(speakEndJs)
                    return@runOnUiThread
                }
                tts?.setSpeechRate(rate.toFloat())
                tts?.setPitch(pitch.toFloat())
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
            }
        }

        @JavascriptInterface
        fun stopSpeak() {
            runOnUiThread { tts?.stop() }
        }

        @JavascriptInterface
        fun listVoices(): String {
            val arr = JSONArray()
            try {
                tts?.voices
                    ?.filter { it.locale.language == "en" }
                    ?.sortedBy { it.name }
                    ?.forEach {
                        arr.put(JSONObject().put("name", it.name).put("lang", it.locale.toLanguageTag()))
                    }
            } catch (e: Exception) {
                // Voice list unavailable on this engine.
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun setVoice(name: String) {
            runOnUiThread {
                if (ttsReady) applyVoice(name) else pendingVoice = name
            }
        }

        @JavascriptInterface
        fun listen(lang: String) {
            runOnUiThread { beginListening(lang) }
        }

        @JavascriptInterface
        fun stopListen() {
            runOnUiThread { recognizer?.stopListening() }
        }

        @JavascriptInterface
        fun scheduleReminder(id: String, text: String, whenMs: String) {
            val at = whenMs.toLongOrNull() ?: return
            Reminders.schedule(this@MainActivity, id, text, at)
        }

        @JavascriptInterface
        fun cancelReminder(id: String) {
            Reminders.cancel(this@MainActivity, id)
        }

        @JavascriptInterface
        fun askPermissions() {
            runOnUiThread {
                val need = mutableListOf<String>()
                if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) {
                    need.add(Manifest.permission.POST_NOTIFICATIONS)
                }
                if (!granted(Manifest.permission.RECORD_AUDIO)) {
                    need.add(Manifest.permission.RECORD_AUDIO)
                }
                if (need.isNotEmpty()) {
                    this@MainActivity.requestPermissions(need.toTypedArray(), 12)
                }
            }
        }
    }
}
